<h1>345678iuygtrdesdcgbhjnhyugtr5fhj</h1>
<?php /**PATH C:\xampp\htdocs\Askka-1\resources\views/product.blade.php ENDPATH**/ ?>